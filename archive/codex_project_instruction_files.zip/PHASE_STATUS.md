# Project Phase Status

> Update at the end of each task using verified artifacts and commands. Mark uninspected or unrerun details as unverified. A recommended next step is not permission to execute it.

## Project
Sprintd Hackathon — Equans “From Tender to First Price”  
Tender: `BKP_244_LV_Lueftung_260804.pdf`  
Expected project root: `D:\Sprintd Hackathon_Equans_Tender to priced offer`

## Last known state from conversation
**Reported state:** Phase B matching and B1 reconciliation completed; reference-example reconciliation and matching regression fixes are not yet verified as implemented. This summary comes from conversation reports; the local files have not been inspected in this setup task.

### Known inputs
- `README.md`
- `example_lv_positions.csv` — reported to contain 22 verified example positions/mappings; verify exact contents and meaning.
- `expected_output_example.json`
- `catalog.csv`
- `productivity.csv`
- `project_parameters.json`
- `BKP_244_LV_Lueftung_260804.pdf`

### Reported Phase 8G baseline
- Full PDF: 202 pages.
- Previous parser output: 216 candidate records.
- Reported status counts: 34 calculated, 10 supplier-quote-required, 8 review-required, 127 insufficient-information, 37 non-priceable.
- Historical figures; inspect artifacts or rerun relevant checks before claiming reproducibility.

### Reported Phase 8H extraction audit
- Initial audit: 259 candidates, estimated 152 distinct positions, 107 possible duplicates/repeated sub-items, 60 ambiguous candidates, 306 excluded Bauteilliste rows.
- The 152 estimate was reported as heuristic, not ground truth.
- A later correction pass was reported completed; Phase B used 222 candidates. Inspect correction artifacts before relying on detailed counts.

### Reported Phase B
Output: `outputs/phase8h_phase_b_matching/`
- 222 input candidates and 222 primary results.
- 63 matched, 159 unmatched.
- 209 human-review queue entries.
- Proposed statuses: 13 calculated, 13 supplier_quote_required, 93 review_required, 103 insufficient_information, 0 assumption_applied.
- No pricing fields/costs reportedly emitted.

### Reported Phase B1 reconciliation
Output: `outputs/phase8h_phase_b_reconciliation/`
- No artifact supporting exactly 32 calculated positions was found.
- Substantiated historical baseline: 34 calculated out of 216.
- Reported reconciliation: 6 remained calculated with same product; 4 remained calculated with changed product ID; 13 downgraded to review_required; 7 downgraded to insufficient_information; 4 removed as false positives; 3 new calculated rows.
- 17 likely matching regressions were flagged, including insulation thickness, fire-seal geometry, TVR-D variants, and air-valve/controller cases.

## Important unresolved issue
The 22 reference examples in `example_lv_positions.csv` have not yet been individually reconciled against the corrected 222-candidate inventory and Phase B results in the conversation. Do not implement matching changes until reference reconciliation and regression evidence have been reviewed.

## Next recommended action
Reconcile every reference example against the corrected inventory and Phase B results; establish whether existing tests exercise the production matching pipeline. Then consider narrowly scoped deterministic matching fixes with regression tests, if supported by evidence.

**Recommendation only. Do not execute without user approval.**

## Per-task checklist
- [ ] Read `README.md`, `PROJECT_RULES.md`, and this file.
- [ ] Read `example_lv_positions.csv` and `expected_output_example.json` for relevant work.
- [ ] Inspect relevant source code, tests, and prior outputs.
- [ ] Confirm task scope and required inputs.
- [ ] Preserve prior artifacts and unrelated working changes.
- [ ] Run relevant tests and record actual outcomes.
- [ ] Update this file with verified results and unresolved issues.
